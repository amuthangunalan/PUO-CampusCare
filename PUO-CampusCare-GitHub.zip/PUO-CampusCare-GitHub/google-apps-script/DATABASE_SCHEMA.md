# PUO CampusCare Database Schema

Create a Google Sheets file named:

```text
PUO_CampusCare_Database
```

## Sheet 1: Dashboard

| Column | Field | Purpose |
|---|---|---|
| A | Metric | Stores KPI name |
| B | Value | Stores KPI value |

Suggested dashboard metrics:

- Total Requests
- Pending Requests
- Completed Requests
- Urgent Requests
- Passed Test Cases
- Final Prototype Status

## Sheet 2: Requests

| Column | Field Name | Description |
|---|---|---|
| A | RequestID | Unique ID such as SRQ001 |
| B | Timestamp | Submission date and time |
| C | StudentName | Full student name |
| D | RegistrationNo | Student registration number |
| E | PhoneNumber | Contact number |
| F | ServiceCategory | Type of campus service |
| G | ServiceDetails | Student request description |
| H | Quantity | Number of requested items/services |
| I | AppointmentDate | Preferred appointment date |
| J | ContactMethod | WhatsApp, Phone Call, or Email |
| K | Priority | Low, Normal, or Urgent |
| L | Status | Pending, In Progress, Completed, Rejected |
| M | AssignedStaff | Staff responsible for request |
| N | Remarks | Admin remarks or system note |

## Sheet 3: ServiceCatalog

| Column | Field Name | Description |
|---|---|---|
| A | ServiceID | Service category ID |
| B | ServiceName | Service name |
| C | Description | Service explanation |
| D | DefaultPriority | Default priority |
| E | AssignedDepartment | Responsible department |

Sample services:

| ServiceID | ServiceName | DefaultPriority | AssignedDepartment |
|---|---|---|---|
| SVC001 | IT Support | Urgent | IT Department |
| SVC002 | Facility | Urgent | Facility Unit |
| SVC003 | Document | Normal | Admin Office |
| SVC004 | Counselling | Normal | Counselling Unit |
| SVC005 | Lost & Found | Normal | Student Affairs |
| SVC006 | General | Normal | General Admin |

## Sheet 4: Students

| Column | Field Name | Description |
|---|---|---|
| A | StudentID | Student unique ID |
| B | FullName | Student full name |
| C | RegistrationNo | Registration number |
| D | PhoneNumber | Contact number |
| E | Email | Student email |
| F | Programme | Student programme |

## Sheet 5: StaffAdmin

| Column | Field Name | Description |
|---|---|---|
| A | StaffID | Staff unique ID |
| B | Username | Login username |
| C | Password | Demo password only |
| D | FullName | Staff full name |
| E | Role | Staff role |
| F | Department | Assigned department |
| G | AccessLevel | Admin/staff permission level |

## Sheet 6: Feedback

| Column | Field Name | Description |
|---|---|---|
| A | FeedbackID | Feedback unique ID |
| B | RequestID | Related request ID |
| C | Rating | Student rating |
| D | Comment | Feedback comment |
| E | DateSubmitted | Feedback date |

## Sheet 7: TestCases

| Column | Field Name | Description |
|---|---|---|
| A | TestID | Test case ID |
| B | Function | Tested function |
| C | Action | Test action |
| D | ExpectedResult | Expected output |
| E | ActualResult | Actual output |
| F | Status | Pass/Fail |

## Sheet 8: Improvements

| Column | Field Name | Description |
|---|---|---|
| A | No | Number |
| B | ProblemFound | Problem identified during testing |
| C | PartInvolved | System part affected |
| D | ImprovementAction | Action taken |
| E | Result | Final result |

