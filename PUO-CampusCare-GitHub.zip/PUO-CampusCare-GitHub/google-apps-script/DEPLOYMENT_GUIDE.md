# Google Apps Script Deployment Guide

## 1. Create Google Sheets Database

1. Create a new Google Sheet.
2. Name it `PUO_CampusCare_Database`.
3. Create these sheets:
   - Dashboard
   - Requests
   - ServiceCatalog
   - Students
   - StaffAdmin
   - Feedback
   - TestCases
   - Improvements
4. Follow `DATABASE_SCHEMA.md` for the columns.

## 2. Add Apps Script Code

1. In Google Sheets, open **Extensions > Apps Script**.
2. Delete the default code.
3. Copy and paste the content from `Code.gs`.
4. Replace:

```js
const SPREADSHEET_ID = 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE';
```

with your actual Google Sheet ID.

The Sheet ID is found in the Google Sheets URL:

```text
https://docs.google.com/spreadsheets/d/SHEET_ID_HERE/edit
```

## 3. Deploy as Web App

Use Apps Script deployment and set:

| Setting | Value |
|---|---|
| Deployment type | Web app |
| Execute as | Me |
| Who has access | Anyone |

Copy the deployed Web App URL.

## 4. Connect Frontend to Backend

Open `frontend/app.js` and paste your Apps Script URL:

```js
const GAS_WEB_APP_URL = "YOUR_WEB_APP_URL";
```

## 5. Test API

Open your Web App URL with this parameter:

```text
?action=test
```

Expected result:

```json
{
  "success": true,
  "message": "PUO CampusCare Apps Script backend is running."
}
```

## 6. Final Demo Flow

1. Open frontend website.
2. Submit a request.
3. Check confirmation message.
4. Open Google Sheets database.
5. Confirm the new row appears in the Requests sheet.
6. Use RequestID to track status.

