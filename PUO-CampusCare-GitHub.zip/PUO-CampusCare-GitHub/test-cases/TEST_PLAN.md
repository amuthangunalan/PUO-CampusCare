# PUO CampusCare Test Plan

**Tester:** KURALAMUTHAN A/L GUANALAN  
**Registration No.:** 01BCE25F3013  
**Testing Method:** Manual testing using sample service request data  
**Final Prototype Status:** Working educational prototype

## Test Case Table

| ID | Function | Action | Expected Result | Actual Result | Status |
|---|---|---|---|---|---|
| TC-01 | Home Page | Open prototype link | Home page opens successfully | Home page opened correctly | Pass |
| TC-02 | Services Page | Open Services section | Service categories are displayed | All services displayed clearly | Pass |
| TC-03 | Request Form | Enter sample request data | Form accepts all required fields | Input accepted | Pass |
| TC-04 | Apps Script Save Function | Submit sample request | Request is processed by Apps Script | Request processed successfully | Pass |
| TC-05 | Google Sheets Database | Check Requests sheet | New request record appears | Record saved with RequestID | Pass |
| TC-06 | Confirmation Message | Submit request successfully | Confirmation with RequestID appears | Message displayed clearly | Pass |
| TC-07 | Status Tracking | Search using RequestID | Request status is displayed | Status shown correctly | Pass |
| TC-08 | Mobile View | Open prototype on small screen | Layout remains readable | Responsive layout is readable | Pass |
| TC-09 | Student Entry | Click student dashboard | Dashboard loads immediately | Dashboard loads with stats cards | Pass |
| TC-10 | Student Registration | Enter name and matrix number | Registration success | Student name appears on dashboard | Pass |
| TC-11 | Staff Login | Enter demo staff credential | Staff dashboard loads | Staff dashboard loads correctly | Pass |
| TC-12 | Urgent Requests | View staff dashboard | Urgent requests displayed | Urgent requests shown clearly | Pass |
| TC-13 | Status Update | Change request status | Status updated in sheet | Request updated successfully | Pass |
| TC-14 | Filter Requests | Select filter dropdown | Requests filtered correctly | Table updates correctly | Pass |
| TC-15 | Dashboard Update | Submit request | Dashboard stats update | Stats update automatically | Pass |

## Problem List and Improvement Action

| No. | Problem Found | Part Involved | Improvement Action | Result |
|---|---|---|---|---|
| 1 | Service description was too short | Services page | Added clearer description and icons | Fixed |
| 2 | Form field name did not match database column | Request form / Requests sheet | Renamed fields to match database columns | Fixed |
| 3 | Confirmation message was too simple | Apps Script / Web app | Added RequestID and status message | Fixed |
| 4 | Status tracking flow was not clear | Status page | Added instruction to enter RequestID | Fixed |

